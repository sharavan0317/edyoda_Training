# coding: cp1252

print('Ol�, Mundo!')
