print ('hello world')

while True:
    pass
