import dicttoxml

doc = dicttoxml.dicttoxml({'a':5,'c':'d'},custom_root='hostel')
print doc