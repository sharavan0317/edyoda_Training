# -*- coding: utf-8 -*-
import os

os.system("python threads-code.py")
