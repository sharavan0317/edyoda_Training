import subprocess

subprocess.run(["ls","-al"])
