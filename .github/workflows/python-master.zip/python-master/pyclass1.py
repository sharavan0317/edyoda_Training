# print 'hi'
# a=5
# print type(a)

# a=6
# b=5

# a,b,c,d=7,8,6,'f'
# print a
# print d

# print str(a)

# # #+ - / * % ** //

# s ='hello'
# print s

# # # > = < !=
# g=7.9
# print g/2.0
# a= a+5
# a+=5

# # #a&=b || a= a&b

# # in, not in 

# # a*5-7&b/9**5

# a =5
# b=8

# if a>7 :
# 	print 'first if statement'
# 	if b>7 :
# 		print 'nested if'

# elif a<4 :
# 	print 'first elif'
# elif a==5:
# 	print 'second elif'
# else :
# 	print 'first else statement'
# a=10
# while a>5 :
# 	a -= 1 #a=a-1
# 	print a

# num = 10

# while num >0 :
# 	if num%2==0 :
# 		print 'number is even  ',num
# 	num -=1

# for num in range(1,10):
# 	if num%2==0:
# 		print 'even   ', num



# for num in range(3,10):
# 	a=0
# 	for prime in range(2,num-1):
# 		if num%prime == 0 :
# 			a += 1
# 	if a==0:
# 		print 'prime number  ', num

#NUMBERS:
#int, float, long, complex
# a=4
# b=5
# print long(a)

# import math

# a =7.6789065444
# b=8
# c=10
# #print abs(a) #absolute value of a

# print round(a,3)

# import random

# l=[3,5.6,'fgh']
# print random.choice(l)
# print random.choice(l)

#print random.randrange(10,100,3)

#print random.random() # random number will always be greater than or equal to 0 and always less than 1.
# random.seed(15)
# print random.random()
# #0.57140259469
# random.seed(15)
# print random.random()
# random.shuffle(l)
# print l[2]
# print random.uniform(2,10)
# import math
# print math.radians(180)
# print math.e































































