import time
while True:
	time.sleep(1)
	print 'Heyyy'