'''
a = 10
if a == 10:
    print a
    print 'Great World'
else:
    print 'Not 10'


'''
'''
data = raw_input('Enter data ')
print type(data) 

if not data.isdigit():
    pass
else:
    print int(data) + 1000

'''
##Looping


l = [1,3,2,2,2,3,98]

for e in l:
    print e

l = ['this','is','good']

for c in l:
    print c,

