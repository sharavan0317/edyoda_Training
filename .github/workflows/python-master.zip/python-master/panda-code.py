import pandas as pd

companies = pd.read_csv('D:\Data\company_master_data_upto_Mar_2015_Karnataka.csv')

print companies.head()













25 < 36
5    6

