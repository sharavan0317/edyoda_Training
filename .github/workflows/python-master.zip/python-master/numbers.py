
from math import *

a= -1.25
print abs(a)
b= 25

print sqrt(b)

a = 6.35
print floor (a)

print min(10,5,6,34,7)
import random

print random.random()

l = ["dfg", 56, 7.8 ,"xyz"]

print random.choice(l)

print random.randrange(10,50,5)

random.shuffle(l)
print l

print random.uniform(3,40)

random.seed(5)

print random.random()



