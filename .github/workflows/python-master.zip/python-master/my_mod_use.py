#import my_mod
from my_mod import Hello
#print my_mod.fun()

x = Hello('awantik')
x.sayHi()
