def func (list1, *str):

	
	
	
	list1.append('rt')
	print list1
	list1=[10,50]
	print str
	s1=[50,70]
	print m

	return list1

def func2 ():
	print 'hello'

	 
	
func2()

m=[40,90]
s= ['hi', 23]
lis = func(s,20,30,40) 
print s
print lis
func2()