l = ['sddf', 4, 5.7, 36, 78]

#print l 

m = ['sddf', 4, 5.6, 47]

# print m[0]

# m[0]=8
# print m

# if 7 not in m:
# 	print "yes"

# del(m[0])
# print m 

# print l[:-1]

# del(l[1:3])
# print l

# print l
l+=m
print l
m = ['abc', 4, 5.6, 47]
print m*3

# print len(l)

# l[3]='third'
# l[1:5]=['our']
# print l

# l.append(789)
# print l

# print l.count(4)

# l.extend(m)
# print l
# print l
# print l.index(78, 0, 5)

# l.insert(2,'second')
# print l 

# l.pop(7)
# print l

# l.remove(4)
# print l 

# l.sort(reverse = True)
# print l 

# n = [1,2,3.4,[5,6,8.7]]
# print n 
# print n[3][2]


k = (1,4,'ghj')
print k
print repr(k)










