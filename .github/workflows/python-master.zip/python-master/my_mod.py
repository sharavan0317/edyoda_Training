def fun():
	return 'Hello World'

class Hello():
	def __init__(self,name):
		self.name = name

	def sayHi(self):
		print 'Hiii ' + self.name