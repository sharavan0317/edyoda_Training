#dict = {'name' : 'abc', 'school' : 'dps', 'age' : 20}

# print dict['age']

# print dict


# dict['name'] = 'def'

# print dict

# dict.clear()

#del(dict['name'])

#print dict

# dict2 = {'name' : 'def', 'age' : 7}

# print len(dict2)

# dict3= dict.copy()
# print dict3
 
# a= [1, 'abc', 'ghi']

# dict1 = {}

# dict1=dict1.fromkeys(a)

# print dict1

# dict2 = {'abc': [1,2]}
# print dict2

dict = {'name' : 'abc', 'school' : 'dps', 'age' : 20}

print dict.has_key('sdf')

print dict.items()

print str(dict)

print dict.keys()

print dict.values()

print dict.setdefault('name', 'none')

print dict.viewitems()

dict1 = {'name' : {'gr':'hi', 'hj':6}}




list= dict1['name']
print list

