s = 'abcdefghijkl'

for i,c in enumerate(s):
	print i,c
	print 'hello world'
		
	print 'great'

print s[3]